make           # Compile project
make run       # Run the project
make memcheck  # Memcheck the project with Valgrind
make clean.    # Clean compiled files