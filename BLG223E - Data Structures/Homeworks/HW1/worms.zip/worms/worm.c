#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define MAX_WORMS 100

typedef struct WormPart {
    int x, y;
} WormPart;

typedef struct Node {
    WormPart* data;
    struct Node* next;
    struct Node* previous;
} Node;

typedef struct DoublyList {
    Node* head;
    Node* tail;
    int elemcount;
} DoublyList;

// Yardımcı fonksiyonlar
bool isAdjacent(WormPart* a, WormPart* b) {
    return (abs(a->x - b->x) + abs(a->y - b->y)) == 1;
}

void initList(DoublyList* list) {
    list->head = list->tail = NULL;
    list->elemcount = 0;
}

// Liste işlemleri
void addBack(DoublyList* list, WormPart* new_element) {
    Node* newnode = (Node*)malloc(sizeof(Node));
    newnode->data = new_element;
    newnode->next = NULL;
    newnode->previous = list->tail;

    if (list->tail != NULL) {
        list->tail->next = newnode;
    } else {
        list->head = newnode;
    }
    list->tail = newnode;
    list->elemcount++;
}

void removeNode(DoublyList* list, Node* node) {
    if (node == NULL || list == NULL) return;

    // Bağlantıları güncelle
    if (node->previous != NULL) {
        node->previous->next = node->next;
    } else {
        list->head = node->next;
    }

    if (node->next != NULL) {
        node->next->previous = node->previous;
    } else {
        list->tail = node->previous;
    }

    // Belleği serbest bırak
    free(node->data);
    free(node);
    list->elemcount--;
}

void destroyList(DoublyList* list) {
    if (list == NULL) return;
    
    Node* current = list->head;
    while (current != NULL) {
        Node* next = current->next;
        free(current->data);
        free(current);
        current = next;
    }
    free(list);
}

// Solucan işlemleri
DoublyList* create_worm(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Error opening file: %s\n", filename);
        return NULL;
    }

    DoublyList* worm = (DoublyList*)malloc(sizeof(DoublyList));
    initList(worm);

    int x, y;
    while (fscanf(file, "%d %d", &x, &y) == 2) {
        WormPart* part = (WormPart*)malloc(sizeof(WormPart));
        part->x = x;
        part->y = y;
        addBack(worm, part);
    }

    fclose(file);
    return worm;
}

void attackWorm(DoublyList* worm, int x, int y) {
    if (worm == NULL || worm->elemcount == 0) return;

    Node* targets[3] = {NULL};
    int targetCount = 0;

    // Saldırılan noktayı ve komşularını bul
    Node* current = worm->head;
    while (current != NULL) {
        if (current->data->x == x && current->data->y == y) {
            targets[targetCount++] = current;
            
            // Önceki node komşu mu?
            if (current->previous != NULL && isAdjacent(current->data, current->previous->data)) {
                targets[targetCount++] = current->previous;
            }
            
            // Sonraki node komşu mu?
            if (current->next != NULL && isAdjacent(current->data, current->next->data)) {
                targets[targetCount++] = current->next;
            }
            break;
        }
        current = current->next;
    }

    // Hedefleri sil (en fazla 3 node)
    for (int i = 0; i < targetCount; i++) {
        if (targets[i] != NULL) {
            removeNode(worm, targets[i]);
        }
    }
}

void splitWorm(DoublyList* original, DoublyList** part1, DoublyList** part2) {
    *part1 = (DoublyList*)malloc(sizeof(DoublyList));
    *part2 = (DoublyList*)malloc(sizeof(DoublyList));
    initList(*part1);
    initList(*part2);

    Node* current = original->head;
    Node* last = NULL;
    
    while (current != NULL) {
        WormPart* new_part = (WormPart*)malloc(sizeof(WormPart));
        new_part->x = current->data->x;
        new_part->y = current->data->y;
        
        // Fiziksel komşuluk kontrolü
        if (last == NULL || isAdjacent(last->data, current->data)) {
            addBack(*part1, new_part);
        } else {
            addBack(*part2, new_part);
        }
        
        last = current;
        current = current->next;
    }
}

// Görüntüleme ve ana işlemler
void printWorms(DoublyList* wormfield[], int wormcount) {
    printf("\nCurrent Worms:\n");
    for (int i = 0; i < wormcount; i++) {
        if (wormfield[i] == NULL || wormfield[i]->elemcount == 0) continue;
        
        printf("Worm %d: ", i+1);
        Node* current = wormfield[i]->head;
        while (current != NULL) {
            printf("(%d,%d) ", current->data->x, current->data->y);
            current = current->next;
        }
        printf("\n");
    }
}

int main() {
    DoublyList* wormfield[MAX_WORMS] = {NULL};
    int wormcount = 4;
    const char* filenames[4] = {"worms/worm1.txt", "worms/worm2.txt", "worms/worm3.txt", "worms/worm4.txt"};

    // Solucanları oluştur
    for (int i = 0; i < wormcount; i++) {
        wormfield[i] = create_worm(filenames[i]);
        if (wormfield[i] == NULL) {
            printf("Error creating worm %d\n", i+1);
            return 1;
        }
    }

    // Ana döngü
    while (1) {
        printWorms(wormfield, wormcount);
        
        printf("\n1. View worms\n");
        printf("2. Attack\n");
        printf("3. Quit\n");
        printf("Choice: ");
        
        int choice;
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input!\n");
            while (getchar() != '\n'); // Girdi buffer'ını temizle
            continue;
        }
        
        if (choice == 1) {
            continue;
        } else if (choice == 2) {
            int x, y;
            printf("Enter coordinates to attack (x y): ");
            if (scanf("%d %d", &x, &y) != 2) {
                printf("Invalid coordinates!\n");
                while (getchar() != '\n');
                continue;
            }
            
            for (int i = 0; i < wormcount; i++) {
                if (wormfield[i] == NULL || wormfield[i]->elemcount == 0) continue;
                
                // Saldırıyı gerçekleştir
                int before = wormfield[i]->elemcount;
                attackWorm(wormfield[i], x, y);
                int after = wormfield[i]->elemcount;
                
                // Solucanı bölmek gerekirse
                if (after > 0 && after < before) {
                    DoublyList* part1 = NULL;
                    DoublyList* part2 = NULL;
                    splitWorm(wormfield[i], &part1, &part2);
                    
                    if (part2->elemcount > 0) {
                        destroyList(wormfield[i]);
                        wormfield[i] = part1;
                        if (wormcount < MAX_WORMS) {
                            wormfield[wormcount++] = part2;
                            printf("Worm split into two!\n");
                        } else {
                            destroyList(part2);
                        }
                    } else {
                        destroyList(part1);
                        destroyList(part2);
                    }
                }
            }
        } else if (choice == 3) {
            break;
        } else {
            printf("Invalid choice!\n");
        }
    }

    // Temizlik
    for (int i = 0; i < wormcount; i++) {
        destroyList(wormfield[i]);
    }

    return 0;
}